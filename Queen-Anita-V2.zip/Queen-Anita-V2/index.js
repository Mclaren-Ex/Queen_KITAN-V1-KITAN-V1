function hi() {
  console.log("Wassup Dude!");
}
hi();
const bot = require(__dirname + '/lib/amd');
const start = async () => {
  Debug.info("INSTALLING QUEEN_KITAN-V1...");
  try {
    await bot.init();
    await bot.DATABASE.sync();
    await bot.connect();
  } catch (_0x120425) {
    Debug.error(_0x120425);
    start();
  }
};
start();